"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight, Play } from "lucide-react"

export default function HomePage() {
  const teamMembers = [
    { name: "Anna Kowalska", role: "Creative Director", avatar: "/professional-woman-avatar.png" },
    { name: "Michał Nowak", role: "Motion Designer", avatar: "/professional-man-avatar.png" },
    { name: "Katarzyna Wiśniewska", role: "Graphic Designer", avatar: "/professional-woman-avatar.png" },
    { name: "Tomasz Wójcik", role: "Video Editor", avatar: "/professional-man-avatar.png" },
    { name: "Magdalena Kaczmarek", role: "3D Artist", avatar: "/professional-woman-avatar.png" },
    { name: "Paweł Zieliński", role: "Brand Designer", avatar: "/professional-man-avatar.png" },
    { name: "Agnieszka Szymańska", role: "UI/UX Designer", avatar: "/professional-woman-avatar.png" },
    { name: "Jakub Dąbrowski", role: "Project Manager", avatar: "/professional-man-avatar.png" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[size:50px_50px] animate-pulse" />
      </div>

      {/* Floating Geometric Shapes */}
      <motion.div
        className="absolute top-20 left-10 w-20 h-20 bg-gradient-to-r from-gray-500 to-gray-300 rounded-lg opacity-20"
        animate={{
          y: [0, -20, 0],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 8,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute top-40 right-20 w-16 h-16 bg-gradient-to-r from-gray-300 to-gray-600 rounded-full opacity-30"
        animate={{
          y: [0, 30, 0],
          x: [0, -10, 0],
        }}
        transition={{
          duration: 6,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 left-1/4 w-12 h-12 bg-gradient-to-r from-gray-400 to-gray-500 transform rotate-45 opacity-25"
        animate={{
          rotate: [45, 225, 405],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 10,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />

      {/* Navigation */}
      <motion.nav
        className="relative z-10 flex items-center justify-between p-6 md:p-8"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="flex items-center space-x-8">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link href="/" className="text-white font-medium hover:text-gray-300 transition-colors">
              Strona Główna
            </Link>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link href="#team" className="text-white font-medium hover:text-gray-300 transition-colors">
              Zespół
            </Link>
          </motion.div>
        </div>

        {/* Logo */}
        <motion.div
          className="flex items-center space-x-3"
          whileHover={{ scale: 1.05 }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <motion.img
            src="/cloudstudio-logo.webp"
            alt="CloudStudio Logo"
            className="w-10 h-10"
            animate={{
              filter: ["brightness(1)", "brightness(1.2)", "brightness(1)"],
            }}
            transition={{
              duration: 3,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
          <div className="text-white font-bold text-xl">
            Cloud<span className="text-gray-300">Studio</span>
          </div>
        </motion.div>

        <div className="flex items-center space-x-8">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link href="/portfolio" className="text-white font-medium hover:text-gray-300 transition-colors">
              Portfolio
            </Link>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <a
              href="https://discord.gg/cloudstudio"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white font-medium hover:text-gray-300 transition-colors"
            >
              Kontakt
            </a>
          </motion.div>
        </div>
      </motion.nav>

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-6 text-center">
        {/* Animated Title */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          <motion.h1
            className="text-5xl md:text-7xl font-bold text-white mb-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.8 }}
          >
            Następny Poziom{" "}
            <motion.span
              className="bg-gradient-to-r from-gray-300 via-white to-gray-400 bg-clip-text text-transparent"
              animate={{
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
              }}
              transition={{
                duration: 3,
                repeat: Number.POSITIVE_INFINITY,
                ease: "easeInOut",
              }}
            >
              Wyobraźni
            </motion.span>
          </motion.h1>

          <motion.p
            className="text-xl md:text-2xl text-gray-300 font-light"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.2 }}
          >
            Tworzymy Przyszłość, Już Teraz
          </motion.p>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 mt-8"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.5 }}
        >
          <motion.div
            whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(255, 255, 255, 0.3)" }}
            whileTap={{ scale: 0.95 }}
          >
            <Link
              href="/portfolio"
              className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-gray-700 to-gray-500 text-white font-semibold rounded-lg hover:from-gray-600 hover:to-gray-400 transition-all duration-300 group"
            >
              Zobacz Nasze Prace
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>

          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <a
              href="https://discord.gg/cloudstudio"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-8 py-4 border-2 border-gray-400 text-gray-400 font-semibold rounded-lg hover:bg-gray-400 hover:text-black transition-all duration-300 group"
            >
              <Play className="mr-2 w-5 h-5 group-hover:scale-110 transition-transform" />
              Dołącz do Nas
            </a>
          </motion.div>
        </motion.div>

        {/* Animated Stats */}
        <motion.div
          className="grid grid-cols-3 gap-8 mt-16 text-center"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 2 }}
        >
          <motion.div whileHover={{ scale: 1.1 }} className="p-4">
            <motion.div
              className="text-3xl font-bold text-gray-300 mb-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 2, delay: 2.2 }}
            >
              100+
            </motion.div>
            <div className="text-gray-400">Projektów</div>
          </motion.div>

          <motion.div whileHover={{ scale: 1.1 }} className="p-4">
            <motion.div
              className="text-3xl font-bold text-white mb-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 2, delay: 2.4 }}
            >
              50+
            </motion.div>
            <div className="text-gray-400">Klientów</div>
          </motion.div>

          <motion.div whileHover={{ scale: 1.1 }} className="p-4">
            <motion.div
              className="text-3xl font-bold text-gray-300 mb-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 2, delay: 2.6 }}
            >
              24/7
            </motion.div>
            <div className="text-gray-400">Wsparcie</div>
          </motion.div>
        </motion.div>
      </div>

      {/* Team Section */}
      <section id="team" className="relative z-10 py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Nasz <span className="text-gray-300">Zespół</span>
            </h2>
            <p className="text-xl text-gray-400">Poznaj ludzi, którzy tworzą magię</p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                className="text-center group"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05 }}
              >
                <div className="relative mb-4">
                  <motion.img
                    src={member.avatar}
                    alt={member.name}
                    className="w-24 h-24 rounded-full mx-auto border-4 border-gray-600 group-hover:border-gray-400 transition-colors duration-300"
                    whileHover={{ scale: 1.1 }}
                  />
                  <motion.div className="absolute inset-0 rounded-full bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">{member.name}</h3>
                <p className="text-gray-400 text-sm">{member.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Animated Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white rounded-full opacity-60"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -100, 0],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: Math.random() * 3 + 2,
            repeat: Number.POSITIVE_INFINITY,
            delay: Math.random() * 2,
          }}
        />
      ))}
    </div>
  )
}
