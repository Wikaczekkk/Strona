"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowLeft, Play, ImageIcon, Video, Palette, X } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useState } from "react"

export default function PortfolioPage() {
  const [selectedCategory, setSelectedCategory] = useState("Wszystkie")
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null)

  const portfolioItems = [
    {
      id: 1,
      title: "Projekt Graficzny - Logo Design",
      category: "Grafika",
      type: "image",
      image: "/modern-logo.png",
      description: "Nowoczesny design logo dla firmy technologicznej",
    },
    {
      id: 2,
      title: "Animacja Produktowa",
      category: "Wideo",
      type: "video",
      image: "/product-animation.png",
      description: "Animacja 3D prezentująca nowy produkt",
      videoId: "dQw4w9WgXcQ", // Example YouTube video ID
    },
    {
      id: 3,
      title: "Identyfikacja Wizualna",
      category: "Grafika",
      type: "image",
      image: "/brand-identity-concept.png",
      description: "Kompletna identyfikacja wizualna marki",
    },
    {
      id: 4,
      title: "Reklama Video",
      category: "Wideo",
      type: "video",
      image: "/video-advertisement.png",
      description: "Dynamiczna reklama video dla mediów społecznościowych",
      videoId: "jNQXAC9IVRw", // Example YouTube video ID
    },
    {
      id: 5,
      title: "Projekt Opakowania",
      category: "Grafika",
      type: "image",
      image: "/package-design.png",
      description: "Kreatywny design opakowania produktu",
    },
    {
      id: 6,
      title: "Motion Graphics",
      category: "Wideo",
      type: "video",
      image: "/abstract-motion-graphics.png",
      description: "Zaawansowana animacja motion graphics",
      videoId: "M7lc1UVf-VE", // Example YouTube video ID
    },
    // Graphics (20 items)
    {
      id: 7,
      title: "Projekt Graficzny - Logo Design",
      category: "Grafika",
      type: "image",
      image: "/modern-logo.png",
      description: "Nowoczesny design logo dla firmy technologicznej",
    },
    {
      id: 8,
      title: "Identyfikacja Wizualna",
      category: "Grafika",
      type: "image",
      image: "/brand-identity-design.png",
      description: "Kompletna identyfikacja wizualna marki",
    },
    {
      id: 9,
      title: "Projekt Opakowania",
      category: "Grafika",
      type: "image",
      image: "/product-packaging-design.png",
      description: "Kreatywny design opakowania produktu",
    },
    {
      id: 10,
      title: "Plakat Reklamowy",
      category: "Grafika",
      type: "image",
      image: "/advertising-poster.png",
      description: "Efektowny plakat reklamowy dla kampanii marketingowej",
    },
    {
      id: 11,
      title: "Design Strony Internetowej",
      category: "Grafika",
      type: "image",
      image: "/website-design-mockup.png",
      description: "Nowoczesny design interfejsu strony internetowej",
    },
    {
      id: 12,
      title: "Wizytówka Biznesowa",
      category: "Grafika",
      type: "image",
      image: "/modern-business-card.png",
      description: "Elegancka wizytówka dla profesjonalistów",
    },
    {
      id: 13,
      title: "Broszura Firmowa",
      category: "Grafika",
      type: "image",
      image: "/corporate-brochure.png",
      description: "Profesjonalna broszura prezentująca usługi firmy",
    },
    {
      id: 14,
      title: "Infografika",
      category: "Grafika",
      type: "image",
      image: "/infographic-design.png",
      description: "Czytelna infografika przedstawiająca dane statystyczne",
    },
    {
      id: 15,
      title: "Okładka Książki",
      category: "Grafika",
      type: "image",
      image: "/abstract-book-cover.png",
      description: "Artystyczna okładka dla publikacji literackiej",
    },
    {
      id: 16,
      title: "Banner Internetowy",
      category: "Grafika",
      type: "image",
      image: "/web-banner-design.png",
      description: "Dynamiczny banner dla kampanii online",
    },
    {
      id: 17,
      title: "Projekt Koszulki",
      category: "Grafika",
      type: "image",
      image: "/abstract-geometric-tee.png",
      description: "Kreatywny design nadruku na koszulkę",
    },
    {
      id: 18,
      title: "Menu Restauracji",
      category: "Grafika",
      type: "image",
      image: "/elegant-restaurant-menu.png",
      description: "Eleganckie menu dla restauracji premium",
    },
    {
      id: 19,
      title: "Kalendarz Firmowy",
      category: "Grafika",
      type: "image",
      image: "/corporate-calendar.png",
      description: "Stylowy kalendarz z motywami firmowymi",
    },
    {
      id: 20,
      title: "Projekt Etykiety",
      category: "Grafika",
      type: "image",
      image: "/product-label.png",
      description: "Atrakcyjna etykieta produktu spożywczego",
    },
    {
      id: 21,
      title: "Grafika Social Media",
      category: "Grafika",
      type: "image",
      image: "/social-media-graphics.png",
      description: "Zestaw grafik do mediów społecznościowych",
    },
    {
      id: 22,
      title: "Projekt Magazynu",
      category: "Grafika",
      type: "image",
      image: "/magazine-layout.png",
      description: "Profesjonalny layout strony magazynu",
    },
    {
      id: 23,
      title: "Certyfikat Uznania",
      category: "Grafika",
      type: "image",
      image: "/elegant-certificate.png",
      description: "Elegancki certyfikat dla wyróżnień",
    },
    {
      id: 24,
      title: "Projekt Aplikacji",
      category: "Grafika",
      type: "image",
      image: "/mobile-app-design-concept.png",
      description: "Interfejs użytkownika aplikacji mobilnej",
    },
    {
      id: 25,
      title: "Zaproszenie Eventowe",
      category: "Grafika",
      type: "image",
      image: "/elegant-event-invitation.png",
      description: "Stylowe zaproszenie na wydarzenie biznesowe",
    },
    {
      id: 26,
      title: "Projekt Prezentacji",
      category: "Grafika",
      type: "image",
      image: "/presentation-design.png",
      description: "Profesjonalny szablon prezentacji PowerPoint",
    },

    // Videos (20 items)
    {
      id: 27,
      title: "Animacja Produktowa",
      category: "Wideo",
      type: "video",
      image: "/product-animation-thumbnail.png",
      description: "Animacja 3D prezentująca nowy produkt",
      videoId: "dQw4w9WgXcQ",
    },
    {
      id: 28,
      title: "Reklama Video",
      category: "Wideo",
      type: "video",
      image: "/video-ad-thumbnail.png",
      description: "Dynamiczna reklama video dla mediów społecznościowych",
      videoId: "jNQXAC9IVRw",
    },
    {
      id: 29,
      title: "Motion Graphics",
      category: "Wideo",
      type: "video",
      image: "/motion-graphics-thumbnail.png",
      description: "Zaawansowana animacja motion graphics",
      videoId: "M7lc1UVf-VE",
    },
    {
      id: 30,
      title: "Prezentacja Firmy",
      category: "Wideo",
      type: "video",
      image: "/corporate-presentation-video.png",
      description: "Profesjonalna prezentacja video firmy",
      videoId: "9bZkp7q19f0",
    },
    {
      id: 31,
      title: "Animacja Logo",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Dynamiczna animacja logo z efektami",
      videoId: "kJQP7kiw5Fk",
    },
    {
      id: 32,
      title: "Explainer Video",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Video wyjaśniające działanie produktu",
      videoId: "fJ9rUzIMcZQ",
    },
    {
      id: 33,
      title: "Teaser Produktu",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Krótki teaser zapowiadający nowy produkt",
      videoId: "YQHsXMglC9A",
    },
    {
      id: 34,
      title: "Animacja Tekstowa",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Efektowna animacja typograficzna",
      videoId: "oHg5SJYRHA0",
    },
    {
      id: 35,
      title: "Video Instruktażowe",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Instruktaż krok po kroku obsługi aplikacji",
      videoId: "ZZ5LpwO-An4",
    },
    {
      id: 36,
      title: "Reklama Społecznościowa",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Krótka reklama dostosowana do social media",
      videoId: "hFZFjoX2cGg",
    },
    {
      id: 37,
      title: "Animacja 2D",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Kolorowa animacja 2D z postaciami",
      videoId: "astISOttCQ0",
    },
    {
      id: 38,
      title: "Video Testimonial",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Profesjonalne video z opiniami klientów",
      videoId: "L_jWHffIx5E",
    },
    {
      id: 39,
      title: "Animacja Infografiki",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Animowana infografika z danymi statystycznymi",
      videoId: "y6120QOlsfU",
    },
    {
      id: 40,
      title: "Intro Kanału",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Dynamiczne intro dla kanału YouTube",
      videoId: "DLzxrzFCyOs",
    },
    {
      id: 41,
      title: "Video Eventowe",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Relacja video z wydarzenia firmowego",
      videoId: "ktvTqknDobU",
    },
    {
      id: 42,
      title: "Animacja Produktowa 3D",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Realistyczna animacja 3D produktu",
      videoId: "Sagg08DrO5U",
    },
    {
      id: 43,
      title: "Video Marketingowe",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Kampania video marketingowa dla e-commerce",
      videoId: "tgbNymZ7vqY",
    },
    {
      id: 44,
      title: "Animacja Procesów",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Animacja przedstawiająca procesy biznesowe",
      videoId: "pAgnJDJN4VA",
    },
    {
      id: 45,
      title: "Video Prezentacyjne",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Video prezentujące nową usługę",
      videoId: "A_MjCqQoLLA",
    },
    {
      id: 46,
      title: "Outro Video",
      category: "Wideo",
      type: "video",
      image: "/placeholder.svg?height=300&width=400",
      description: "Profesjonalne outro z call-to-action",
      videoId: "Hi4z0S8jfbU",
    },
  ]

  const categories = ["Wszystkie", "Grafika", "Wideo"]

  // Filter items based on selected category
  const filteredItems =
    selectedCategory === "Wszystkie"
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === selectedCategory)

  const handleVideoPlay = (videoId: string) => {
    setSelectedVideo(videoId)
  }

  const closeVideoModal = () => {
    setSelectedVideo(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      {/* Navigation */}
      <motion.nav
        className="relative z-10 flex items-center justify-between p-6 md:p-8"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Link
            href="/"
            className="inline-flex items-center text-white font-medium hover:text-gray-300 transition-colors"
          >
            <ArrowLeft className="mr-2 w-5 h-5" />
            Powrót do Strony Głównej
          </Link>
        </motion.div>

        {/* Logo */}
        <motion.div className="flex items-center space-x-3" whileHover={{ scale: 1.05 }}>
          <motion.img
            src="/cloudstudio-logo.webp"
            alt="CloudStudio Logo"
            className="w-8 h-8"
            animate={{
              filter: ["brightness(1)", "brightness(1.2)", "brightness(1)"],
            }}
            transition={{
              duration: 3,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          />
          <div className="text-white font-bold text-xl">
            Cloud<span className="text-gray-300">Studio</span>
          </div>
        </motion.div>

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <a
            href="https://discord.gg/cloudstudio"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white font-medium hover:text-gray-300 transition-colors"
          >
            Kontakt
          </a>
        </motion.div>
      </motion.nav>

      {/* Header */}
      <div className="relative z-10 text-center py-16 px-6">
        <motion.h1
          className="text-5xl md:text-6xl font-bold text-white mb-6"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          Nasze{" "}
          <span className="bg-gradient-to-r from-gray-300 via-white to-gray-400 bg-clip-text text-transparent">
            Portfolio
          </span>
        </motion.h1>

        <motion.p
          className="text-xl text-gray-300 max-w-2xl mx-auto"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          Odkryj nasze najlepsze prace graficzne i filmowe
        </motion.p>
      </div>

      {/* Category Filter */}
      <motion.div
        className="relative z-10 flex justify-center mb-12 px-6"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
      >
        <div className="flex space-x-4 bg-gray-800/50 backdrop-blur-sm rounded-lg p-2">
          {categories.map((category, index) => (
            <motion.button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                selectedCategory === category
                  ? "bg-gradient-to-r from-gray-600 to-gray-500 text-white shadow-lg"
                  : "text-white hover:bg-gray-500/20"
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {category}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* Portfolio Grid */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              layout
            >
              <Card className="bg-gray-800/50 backdrop-blur-sm border-gray-700 overflow-hidden group hover:border-gray-500/50 transition-all duration-300">
                <CardContent className="p-0">
                  <div className="relative overflow-hidden">
                    <motion.img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-64 object-cover"
                      whileHover={{ scale: 1.1 }}
                      transition={{ duration: 0.3 }}
                    />

                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute bottom-4 left-4 right-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            {item.type === "video" ? (
                              <Video className="w-5 h-5 text-gray-300" />
                            ) : (
                              <ImageIcon className="w-5 h-5 text-white" />
                            )}
                            <span className="text-sm text-white font-medium">{item.category}</span>
                          </div>

                          <motion.button
                            className="w-10 h-10 bg-gray-600 rounded-full flex items-center justify-center text-white hover:bg-gray-500 transition-colors"
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            onClick={() => {
                              if (item.type === "video" && item.videoId) {
                                handleVideoPlay(item.videoId)
                              }
                            }}
                          >
                            <Play className="w-4 h-4" />
                          </motion.button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                    <p className="text-gray-400 text-sm">{item.description}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <motion.div
        className="relative z-10 text-center py-20 px-6"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1 }}
      >
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">Masz Pomysł na Projekt?</h2>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Skontaktuj się z nami i stwórzmy coś niesamowitego razem
        </p>

        <motion.div
          whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(255, 255, 255, 0.3)" }}
          whileTap={{ scale: 0.95 }}
        >
          <a
            href="https://discord.gg/cloudstudio"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-gray-700 to-gray-500 text-white font-semibold rounded-lg hover:from-gray-600 hover:to-gray-400 transition-all duration-300"
          >
            <Palette className="mr-2 w-5 h-5" />
            Rozpocznij Projekt
          </a>
        </motion.div>
      </motion.div>

      {/* Floating Elements */}
      <motion.div
        className="absolute top-1/4 left-10 w-16 h-16 bg-gradient-to-r from-gray-500 to-gray-300 rounded-lg opacity-20"
        animate={{
          y: [0, -20, 0],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 8,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute top-1/2 right-20 w-12 h-12 bg-gradient-to-r from-gray-300 to-gray-600 rounded-full opacity-30"
        animate={{
          y: [0, 30, 0],
          x: [0, -10, 0],
        }}
        transition={{
          duration: 6,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />

      {/* Video Modal */}
      {selectedVideo && (
        <motion.div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeVideoModal}
        >
          <motion.div
            className="relative w-full max-w-4xl aspect-video bg-black rounded-lg overflow-hidden"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={closeVideoModal}
              className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <iframe
              src={`https://www.youtube.com/embed/${selectedVideo}?autoplay=1`}
              title="YouTube video player"
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </motion.div>
        </motion.div>
      )}
    </div>
  )
}
